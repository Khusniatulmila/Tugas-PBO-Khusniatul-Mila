/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Mila;

/**
 *
 * @author ASUS
 */
public class biodata_saya {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         String nama="Khusniatul Mila";
         String jk="Perempuan";
         String Alt="KR.Menggah,Wonorejo,Pasuruan";
         String jurusan="Rekayasa Perangkat Lunak";
         
         System.out.println("Biodata Saya:");
         System.out.println("-------------");
         System.out.println("Nama \t\t\t\t :"+nama);
         System.out.println("Jenis Kelamin \t\t :"+jk);
         System.out.println("Alamat \t\t\t\t :"+Alt);
         System.out.println("Nama \t\t\t :"+jurusan);
    }
    
    
}
